#include "SystemMenu.h"
#include"LoginSystem.h"
#include "Stock.h"
#include "AddStock.h"
#include "EditStock.h"


void SystemMenu::AdminMenu()
{
	cout << endl;
	cout << "Warehouse Management Admin Menu " << endl;
	cout << "==================================" << endl;
	cout << "1) Generate Summary Report " << endl;
        cout << "2) Register account " << endl;
	cout << "3) Logout " << endl;
	cout << "==================================" << endl;
}

void SystemMenu::WorkerMenu()
{
	cout << endl;
	cout << "Warehouse Management Worker Menu " << endl;
	cout << "==================================" << endl;
	cout << "1) Search Stock " << endl;
	cout << "2) Perform Transaction " << endl;
	cout << "3) Logout " << endl;
	cout << "==================================" << endl;
}

void SystemMenu::TMenu()
{
	cout << endl;
	cout << "Warehouse Management Transaction Menu " << endl;
	cout << "==================================" << endl;
	cout << "1) Add Stock " << endl;
	cout << "2) Remove Stock " << endl;
	cout << "3) Edit Stock " << endl;
	cout << "4) Back to Worker Menu " << endl;
	cout << "==================================" << endl;
}

void SystemMenu::GetAdminChoice()
{
	LoginSystem LoginScreen;

	while (true)
	{
		cout << "Please enter your choice: ";
		cin >> choice;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good() && choice >= 1 && choice <= 3)
			break;

		// If not valid, prompt user and clear previous cin
		cout << "Please key in a valid choice!!!" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
		GetAdminChoice();
	}

	switch (choice)//Start of switch
	{
	case 1:
		GetSummaryReportChoice();
		break;

	case 2:
		LoginScreen.RegisterPage();
        	AdminMenu();
		GetAdminChoice();
		break;

	case 3:
		LoginScreen.LoginMenu();
		LoginScreen.GetSelection();
		break;
	}//End switch
}

void SystemMenu::GetWorkerChoice()
{
	SearchStock search;
	LoginSystem LoginScreen;
	
	while (true)
	{
		cout << "Please enter your choice: ";
		cin >> choice;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good() && choice >= 1 && choice <= 3)
			break;

		// If not valid, prompt user and clear previous cin
		cout << "Please key in a valid choice!!!" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
		GetWorkerChoice();
	}

	switch (choice)//Start of switch
	{
	case 1:
		search.searchStock();
		WorkerMenu();
		GetWorkerChoice();
		break;

	case 2:
		TMenu();
        GetTChoice();
		WorkerMenu();
		GetWorkerChoice();
		break;

	case 3:
		LoginScreen.LoginMenu();
		LoginScreen.GetSelection();
		break;
	}
}
void SystemMenu::GetTChoice()
{
	AddStock pst;
    EditStock edit;
    RemoveStock re;
	Stock s;
	LoginSystem LoginScreen;
	
	while (true)
	{
		cout << "Please enter your choice: ";
		cin >> choice;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good() && choice >= 1 && choice <= 4)
			break;

		// If not valid, prompt user and clear previous cin
		cout << "Please key in a valid choice!!!" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
		GetWorkerChoice();
	}
	
	switch (choice)//Start of switch
	{
	case 1:
		pst.addStock(s.itemID, s.incomingQty, s.itemDescrip, s.price, s.catergory, s.subcatergory, s.transactionDate);
		TMenu();
		GetTChoice();
		break;

	case 2:
		re.removeStock();
		TMenu();
		GetTChoice();
		break;

	case 3:
		edit.editStock();
		TMenu();
		GetTChoice();
		break;

	case 4:
		WorkerMenu();
        GetWorkerChoice();
		break;
	}
};

void SystemMenu::GetSummaryReportChoice()		
{
	Summary generate;
		
	generate.summary();
	
	AdminMenu();
	GetAdminChoice();
}
