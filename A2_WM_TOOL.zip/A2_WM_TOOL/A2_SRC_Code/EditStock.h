
#ifndef EDITSTOCK_H
#define EDITSTOCK_H

// ------------------------------------------------------------------------------------

#include <vector>
#include <string>
using namespace std;

// ------------------------------------------------------------------------------------


#endif // EDITSTOCK_H


