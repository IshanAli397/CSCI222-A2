#ifndef STOCK_H
#define STOCK_H

// ------------------------------------------------------------------------------------

#include <vector>
#include <string>
#include <iostream>     // std::cout
#include <iomanip>      // std::put_time
#include <ctime>        // std::time_t, struct std::tm, std::localtime
#include <chrono>       // std::chrono::system_clock
#include <string>		// std::string
#include <sstream>		// std::convert char to string
#include <fstream>		// std::input and output files
using namespace std;

// ------------------------------------------------------------------------------------

struct WarehouseDB
{
	int itemId;
	string itemDesc;
	string itemCat;
	string itemSubCat;
	double price;
	int qty;
	string month1;
	string date;
	
	char dash;
	int day;
	int year;
};

class Summary
{
	public:
		void summary();
};

class SearchStock
{
	public:
		void searchStock();
};

class EditStock
{
	public:
		void editStock();
};

class RemoveStock
{
	public:
		void removeStock();
};

class Stock
{
	public:
		fstream filestream, ofilestream;
		stringstream cts;
		int itemID, incomingQty, outgoingQty;
		float price;	
		string itemDescrip, catergory, subcatergory, transactionDate, filename = "/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt";

};
#endif // STOCK_H


