#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "EditStock.h"
#include "Stock.h"

using namespace std;


vector <WarehouseDB> editVector;



void EditStock::editStock()
{
	fstream filestream;
	string filename = "/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt";
	WarehouseDB data;

	int itemId;
	string itemDesc;
	string itemCat;
	string itemSubCat;
	double price;
	int qty;
	string date;
	int id;
	int subChoice;

	string category;
	string subCategory;

	cin.clear();
	cin.ignore(1000, '\n');

		cout << endl << "Welcome to Edit Stock" << endl;
		cout << "______________________" << endl << endl;
		cout << "Please enter an Item ID you want to edit: ";
		cin >> id;

		cin.clear();
		cin.ignore(1000, '\n');

		while (true)
		{
		cout << endl<< endl<< "Please select what would you like to edit "<< endl;
		cout << "*********************************" << endl;
		cout << "1) Description " << endl;
		cout << "2) Category " << endl;
		cout << "3) Sub Category " << endl;
		cout << "4) Price " << endl;
		cout << "*********************************" << endl;
		cout << "Your choice: ";
		cin >> subChoice;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good() && subChoice >= 1 && subChoice <= 4)
		break;

		// If not valid, prompt user and clear previous cin
		cout << "Please key in a valid choice!!!" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
		}

		
		if (subChoice == 1)
		{
			string newDesc;
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Please enter a new description: ";
			getline(cin, newDesc);



			filestream.open(filename.c_str(), fstream::in);

			if (!filestream)
			{
				cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
			}
			else
			{
				string aLine = "";
				while (getline(filestream, aLine))
				{
					istringstream ss(aLine);
	

					ss >> data.itemId;
					if(data.itemId == id)
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						data.itemDesc = newDesc;
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
					else
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
				}
			}

		}//End sub choice 1


		else if (subChoice == 2)
		{
			string newCat;
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Please enter a new category: ";
			getline(cin, newCat);



			filestream.open(filename.c_str(), fstream::in);

			if (!filestream)
			{
				cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
			}
			else
			{
				string aLine = "";
				while (getline(filestream, aLine))
				{
					istringstream ss(aLine);
	

					ss >> data.itemId;
					if(data.itemId == id)
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						data.itemCat = newCat;
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
					else
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
				}
			}

		}//End sub choice 2


		else if (subChoice == 3)
		{
			string newSubCat;
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Please enter a new sub-category: ";
			getline(cin, newSubCat);



			filestream.open(filename.c_str(), fstream::in);

			if (!filestream)
			{
				cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
			}
			else
			{
				string aLine = "";
				while (getline(filestream, aLine))
				{
					istringstream ss(aLine);
	

					ss >> data.itemId;
					if(data.itemId == id)
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						data.itemSubCat = newSubCat;
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
					else
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
				}
			}

		}//End sub choice 3


		else if (subChoice == 4)
		{
			double newPrice;
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Please enter a new price: ";
			cin >> newPrice;
                        while (!cin || newPrice < 0)
                        {
				cin.clear();
				cin.ignore(1000, '\n');
				cout << "Please enter a new price: ";
				cin >> newPrice;
			}

			filestream.open(filename.c_str(), fstream::in);

			if (!filestream)
			{
				cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
			}
			else
			{
				string aLine = "";
				while (getline(filestream, aLine))
				{
					istringstream ss(aLine);
	

					ss >> data.itemId;
					if(data.itemId == id)
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						data.price = newPrice;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
					else
					{
						ss.ignore(1, ':');
						getline(ss, data.itemDesc, ':');
						getline(ss, data.itemCat, ':');
						getline(ss, data.itemSubCat, ':');
						ss >> data.price;
						ss.ignore(1, ':');
						ss >> data.qty;
						ss.ignore(1, ':');
						getline(ss, data.date, ':');

						editVector.push_back(data);
					}
				}
			}

		}

fstream ofilestream;

ofilestream.open("/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt", std::ofstream::out | std::ofstream::trunc);
ofilestream.close();

ofilestream.open("/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt", ios::app);

		for (int i = 0; i<editVector.size(); i++)
		{

	//[Item ID]:[Item Description]:[Item Category]:[Item Sub - category]:[Amount Per Unit]:[Qty]:[Transacted date]
	ofilestream << editVector.at(i).itemId << ":" << editVector.at(i).itemDesc << ":" << editVector.at(i).itemCat << ":" << editVector.at(i).itemSubCat << ":" << editVector.at(i).price << ":" << editVector.at(i).qty << ":" << editVector.at(i).date << endl;



		}
	ofilestream.close();
		
editVector.clear();
}//End trackStock()


