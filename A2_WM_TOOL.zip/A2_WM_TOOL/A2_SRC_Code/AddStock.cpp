#include "AddStock.h"

void AddStock::addStock(int addstockitemID, int addstockincomingQty, string addstockitemDescrip, float addstockprice, string addstockcatergory, string addstocksubcatergory, string addstocktransactionDate)
{

	cout << "Please key in the following: \n"
		"\nItem ID\t\t\t: ";
	cin >> addstockitemID;
	while (!cin)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "\nItem ID\t\t\t: ";
		cin >> addstockitemID;
	}

	cout << "\nItem Description\t: ";
	cin.ignore(1000, '\n');
	getline(cin, addstockitemDescrip);

	cout << "\nItem Catergory\t\t: ";
	getline(cin, addstockcatergory);

	cout << "\nItem Sub-Catergory\t: ";
	getline(cin, addstocksubcatergory);

	cout << "\nAmount per Price Unit\t: ";
	cin >> addstockprice;
	while (!cin || addstockprice < 0)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "\nAmount per Price Unit\t: ";
		cin >> addstockprice;
	}
	
	cout << "\nItem Quantity\t\t: ";
	cin >> addstockincomingQty;
	while (!cin || addstockincomingQty < 1)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "\nItem Quantity\t\t: ";
		cin >> addstockincomingQty;
	}

	// current date/time based on current system
	time_t now;
	struct tm* timeinfo;
	time(&now);
	timeinfo = localtime(&now);
	char buffer[80];
	
	strftime(buffer, 80, "%d-%b-%y", timeinfo);
	addstocktransactionDate = buffer;             
	cout << "\nTransaction Date\t: " << addstocktransactionDate;	//%d-%b-%y
	
	//filestream.open(filename.c_str(), fstream::in);		//Open file , read data
	ofilestream.open(filename.c_str(), ios::app);
	//[Item ID]:[Item Description]:[Item Category]:[Item Sub - category]:[Amount Per Unit]:[Qty]:[Transacted date]
	ofilestream << addstockitemID << ":" << addstockitemDescrip << ":" << addstockcatergory << ":" << addstocksubcatergory << ":" << addstockprice << ":" << addstockincomingQty << ":" << addstocktransactionDate << endl;
	ofilestream.close();
}
