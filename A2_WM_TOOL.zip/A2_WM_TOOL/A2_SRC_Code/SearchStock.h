
#ifndef SEARCHSTOCK_H
#define SEARCHSTOCK_H

// ------------------------------------------------------------------------------------

#include <vector>
#include <string>
using namespace std;

// ------------------------------------------------------------------------------------


ostream& HeadingSearch(ostream &os)
{
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	os << "ID   " << "Description                   " << "Category      " << "Sub-Category    " << "Price  " << "Quantity   " << "Date                ";
	os << '\n';
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	return os.flush();

};

ostream& manipIdSearch(ostream &os)
{

	os.width(5);
	os << left;
	return os.flush();

};

ostream& manipDescSearch(ostream &os)
{

	os.width(30);
	os << left;
	return os.flush();

};

ostream& manipCatSearch(ostream &os)
{

	os.width(14);
	os << left;
	return os.flush();

};

ostream& manipSubCatSearch(ostream &os)
{

	os.width(16);
	os << left;
	return os.flush();

};

ostream& manipPriceSearch(ostream &os)
{

	os.width(7);
	os << left;
	return os.flush();

};

ostream& manipQtySearch(ostream &os)
{

	os.width(11);
	os << left;
	return os.flush();

};

ostream& manipDateSearch(ostream &os)
{

	os.width(9);
	os << left;
	return os.flush();

};

#endif // SEARCHSTOCK_H


