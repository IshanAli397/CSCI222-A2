#ifndef LOGINSYSTEM_H
#define LOGINSYSTEM_H

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <sstream>
#include <set>
#include <iomanip>
#include <math.h>
#include <cstring>
#include <string.h>
#include <vector>



#define INPUT_FILE_NAME "/home/vmw_ubuntu/Desktop/Assn2/A2_Data/LoginSystemDatabase.txt"
#define LINE_DATA_DELIMITER 	':'

using namespace std;

struct LoginRecord
{
	string Username;
	string Password;
	string Name;
	string Email;
	string Address;
	int Contact;
	string AccessLVL;
};
class LoginSystem
{
public:

	string username, password, name, email, address, accesslvl;
	int Selection, RecordRead, contact;

	void LoginMenu();
	void LoginPage();
	void RegisterPage();
	void GetSelection();
	void ReadDatabase();

protected:
	string Encrypt(string,string);
};
#endif // !LOGINSYSTEM_H

