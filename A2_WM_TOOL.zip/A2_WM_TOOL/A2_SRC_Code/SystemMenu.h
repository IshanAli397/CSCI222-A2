
#ifndef SYSTEMMENU_H
#define SYSTEMMENU_H

// ------------------------------------------------------------------------------------

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>



using namespace std;

// ------------------------------------------------------------------------------------


class SystemMenu
{
public:

	int choice;

	
	void AdminMenu();
	void GetAdminChoice();
	void GetWorkerChoice();
	void SummaryReportSubMenu();
	void GetSummaryReportChoice();
	void WorkerMenu();
        void TMenu();
        void GetTChoice();
        
};

#endif // SYSTEMMENU_H


