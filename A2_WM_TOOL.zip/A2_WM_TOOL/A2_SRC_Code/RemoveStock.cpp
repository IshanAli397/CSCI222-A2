#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "RemoveStock.h"
#include "Stock.h"

using namespace std;


vector <WarehouseDB> removeVector;



void RemoveStock::removeStock()
{
	fstream filestream;
	string filename = "/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt";
	WarehouseDB data;

	int itemId;
	string itemDesc;
	string itemCat;
	string itemSubCat;
	double price;
	int qty;
	string date;
	int id;
	int subChoice;

	string category;
	string subCategory;

	cin.clear();
	cin.ignore(1000, '\n');

	cout << endl << "Welcome to Remove Stock" << endl;
	cout << "______________________" << endl << endl;
	cout << "Please enter an Item ID you want to remove: ";
	cin >> id;
	cin.clear();
	cin.ignore(1000, '\n');

	filestream.open(filename.c_str(), fstream::in);

	if (!filestream)
	{
		cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
	}
	else
	{
		string aLine = "";
		while (getline(filestream, aLine))
		{
			istringstream ss(aLine);
			ss >> data.itemId;
			if(data.itemId != id)
			{
				ss.ignore(1, ':');
				getline(ss, data.itemDesc, ':');
				getline(ss, data.itemCat, ':');
				getline(ss, data.itemSubCat, ':');
				ss >> data.price;
				ss.ignore(1, ':');
				ss >> data.qty;
				ss.ignore(1, ':');
				getline(ss, data.date, ':');
				removeVector.push_back(data);
			}
		}
	}

/*                                  */

		

fstream ofilestream;

ofilestream.open("/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt", std::ofstream::out | std::ofstream::trunc);
ofilestream.close();

ofilestream.open("/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt", ios::app);

		for (int i = 0; i<removeVector.size(); i++)
		{

	//[Item ID]:[Item Description]:[Item Category]:[Item Sub - category]:[Amount Per Unit]:[Qty]:[Transacted date]
	ofilestream << removeVector.at(i).itemId << ":" << removeVector.at(i).itemDesc << ":" << removeVector.at(i).itemCat << ":" << removeVector.at(i).itemSubCat << ":" << removeVector.at(i).price << ":" << removeVector.at(i).qty << ":" << removeVector.at(i).date << endl;



		}
	ofilestream.close();
		
removeVector.clear();
}//End trackStock()

