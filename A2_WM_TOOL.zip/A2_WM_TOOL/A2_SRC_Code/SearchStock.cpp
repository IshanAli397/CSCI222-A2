#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "Stock.h"
#include "SearchStock.h"

using namespace std;


vector <WarehouseDB> searchVector;

void SearchStock::searchStock()
{
	fstream filestream;
	string filename = "/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt";
	WarehouseDB data;

	int itemId;
	string itemDesc;
	string itemCat;
	string itemSubCat;
	double price;
	int qty;
	string date;

	string category;
	string subCategory;

	cin.clear();
	cin.ignore(1000, '\n');
		filestream.open(filename.c_str(), fstream::in);

		if (!filestream)
		{
			cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
		}
		else
		{
			string aLine = "";
			while (getline(filestream, aLine))
			{
				istringstream ss(aLine);
	
				ss >> data.itemId;
				ss.ignore(1, ':');
				getline(ss, data.itemDesc, ':');
				getline(ss, data.itemCat, ':');
				getline(ss, data.itemSubCat, ':');
				ss >> data.price;
				ss.ignore(1, ':');
				ss >> data.qty;
				ss.ignore(1, ':');
				getline(ss, data.date, ':');

				searchVector.push_back(data);

			}
		}



	int subChoice;
	
	cout << endl;
	cout << "Search Stock Sub-Menu" << endl;	
	cout << "*********************************" << endl;
	cout << "1) Search by Category " << endl;
	cout << "2) Search by Quantity " << endl;
	cout << "3) Search by Price " << endl;
	cout << "*********************************" << endl;

	while (true)
	{
		cout << "Please enter your choice: ";
		cin >> subChoice;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good() && subChoice >= 1 && subChoice <= 3)
		break;

		// If not valid, prompt user and clear previous cin
		cout << "Please key in a valid choice!!!" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
	}


		if(subChoice == 1)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cout << endl << "Welcome to category search" << endl;
			cout << "______________________" << endl << endl;
			cout << "Please enter a category you want to track: ";
			getline(cin, category);


			cout << "Please enter a sub-category you want to track: ";
			getline(cin, subCategory);
			cout <<endl<<endl;


			cout << HeadingSearch;
			if (subCategory == "")
			{
				for (int i = 0; i<searchVector.size(); i++)
				{

					if (searchVector.at(i).itemCat == category)
					{
					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
					}
				}
			}

			else if (category == "")
			{
				for (int i = 0; i<searchVector.size(); i++)
				{

					if (searchVector.at(i).itemSubCat == subCategory)
					{
					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
					}
				}

			}

			else
			{
				for (int i = 0; i<searchVector.size(); i++)
				{

					if (searchVector.at(i).itemCat == category && searchVector.at(i).itemSubCat == subCategory)
					{
					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
					}
				}

			}
		}//End sub choice 1

		else if(subChoice == 2)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			int qtySubChoice;
	
			cout << endl;
			cout << "Quantity Sub-Menu" << endl;	
			cout << "*********************************" << endl;
			cout << "1) Ascending " << endl;
			cout << "2) Descending " << endl;
			cout << "*********************************" << endl;

			while (true)
			{
				cout << "Please enter your choice: ";
				cin >> qtySubChoice;

				// check if input is a valid integer and valid choice; break from loop if valid.
				if (cin.peek() == '\n' && cin.good() && qtySubChoice >= 1 && qtySubChoice <= 2)
				break;

				// If not valid, prompt user and clear previous cin
				cout << "Please key in a valid choice!!!" << endl;
				cin.clear();
				cin.ignore(1000, '\n');
			}

			if(qtySubChoice == 1)
			{
				cin.clear();
				cin.ignore(1000, '\n');
				cout << endl << "Displaying Quantity Search in ascending order-->" << endl;
				sort(searchVector.begin(), searchVector.end(), [](WarehouseDB &a, WarehouseDB &b) {return a.qty < b.qty; });
				cout << HeadingSearch;
				for (int i = 0; i<searchVector.size(); i++)
				{

					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
				}
			}

			else if(qtySubChoice == 2)
			{
				cin.clear();
				cin.ignore(1000, '\n');
				cout << endl << "Displaying Quantity Search in descending order-->" << endl;
				sort(searchVector.begin(), searchVector.end(), [](WarehouseDB &a, WarehouseDB &b) {return a.qty > b.qty; });
				cout << HeadingSearch;
				for (int i = 0; i<searchVector.size(); i++)
				{

					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
				}
			}

		}

		else if(subChoice == 3)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			int priceSubChoice;
	
			cout << endl;
			cout << "Price Sub-Menu" << endl;	
			cout << "*********************************" << endl;
			cout << "1) Ascending " << endl;
			cout << "2) Descending " << endl;
			cout << "*********************************" << endl;

			while (true)
			{
				cout << "Please enter your choice: ";
				cin >> priceSubChoice;

				// check if input is a valid integer and valid choice; break from loop if valid.
				if (cin.peek() == '\n' && cin.good() && priceSubChoice >= 1 && priceSubChoice <= 2)
				break;

				// If not valid, prompt user and clear previous cin
				cout << "Please key in a valid choice!!!" << endl;
				cin.clear();
				cin.ignore(1000, '\n');
			}

			if(priceSubChoice == 1)
			{
				cin.clear();
				cin.ignore(1000, '\n');
				cout << endl << "Displaying Price Search in ascending order-->" << endl;
				sort(searchVector.begin(), searchVector.end(), [](WarehouseDB &a, WarehouseDB &b) {return a.price < b.price; });
				cout << HeadingSearch;
				for (int i = 0; i<searchVector.size(); i++)
				{

					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
				}
			}

			else if(priceSubChoice == 2)
			{
				cin.clear();
				cin.ignore(1000, '\n');
				cout << endl << "Displaying Price Search in descending order-->" << endl;
				sort(searchVector.begin(), searchVector.end(), [](WarehouseDB &a, WarehouseDB &b) {return a.price > b.price; });
				cout << HeadingSearch;
				for (int i = 0; i<searchVector.size(); i++)
				{

					cout << manipIdSearch << searchVector.at(i).itemId;
					cout << manipDescSearch << searchVector.at(i).itemDesc;
					cout << manipCatSearch << searchVector.at(i).itemCat;
					cout << manipSubCatSearch << searchVector.at(i).itemSubCat;
					cout << manipPriceSearch << searchVector.at(i).price;
					cout << manipQtySearch << searchVector.at(i).qty;
					cout << manipDateSearch << searchVector.at(i).date;
					cout << endl;
				}
			}

		}

searchVector.clear();
}//End trackStock()


