#ifndef REMOVESTOCK_H
#define REMOVESTOCK_H

// ------------------------------------------------------------------------------------

#include <vector>
#include <string>
using namespace std;

// ------------------------------------------------------------------------------------


#endif // REMOVESTOCK_H


