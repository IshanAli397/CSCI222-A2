#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include "LoginSystem.h"
#include "SystemMenu.h"

using namespace std;

vector<LoginRecord> LoginRec;

int getch() {
    int ch;
    struct termios t_old, t_new;

    tcgetattr(STDIN_FILENO, &t_old);
    t_new = t_old;
    t_new.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &t_new);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &t_old);
    return ch;
}


string getpass(const char *prompt, bool show_asterisk=true)
{
  const char BACKSPACE=127;
  const char RETURN=10;

  string password;
  unsigned char ch=0;

  cout <<prompt;

  while((ch=getch())!=RETURN)
    {
       if(ch==BACKSPACE)
         {
            if(password.length()!=0)
              {
                 if(show_asterisk)
                 cout <<"\b \b";
                 password.resize(password.length()-1);
              }
         }
       else
         {
             password+=ch;
             if(show_asterisk)
                 cout <<'*';
         }
    }
  cout <<endl;
  return password;
}

void LoginSystem::LoginMenu()
{
	cout << endl;
	cout << "Warehouse Management Login System" << endl;
	cout << "===================================" << endl;
	cout << "1) Login" << endl;
	cout << "2) Exit" << endl;
	cout << "===================================" << endl;
	cout << "Please enter your Option : ";
}

void LoginSystem::LoginPage()
{
	cout << "\n";
	cout << "Warehouse Management Login page" << endl;
	cout << "===================================" << endl;
	cout << "Username: ";
	getline(cin, username);

	string password = getpass("Password: ",true);//User keying password will show * 

	bool loginfound = false;
	int accesstype = 0;


	for (int i = 0; i < LoginRec.size(); i++)
	{
		if (LoginRec.at(i).Username == username && LoginRec.at(i).Password == Encrypt(password,"blah"))
		{
			loginfound = true;

			if (LoginRec.at(i).AccessLVL == "Admin")
			{
				accesstype = 1;		
			}
			else if (LoginRec.at(i).AccessLVL == "Worker")
			{
				accesstype = 2;
			}
		}
	}


	if (loginfound)
	{
		SystemMenu menu;

		cout << "Login Success!" << endl;
		switch (accesstype)
		{
		case 1:
			menu.AdminMenu();
			menu.GetAdminChoice();
			break;

		case 2 :
			menu.WorkerMenu();
			menu.GetWorkerChoice();
			break;
		}

	}
	else
	{
		cout << "Invalid Username or Password!" << endl;
		LoginPage();
	}

}


string LoginSystem::Encrypt(string msg, string key)
{
	string tmp(key);
    while (key.size() < msg.size())
        key += tmp;
    
    // And now for the encryption part
    for (string::size_type i = 0; i < msg.size(); ++i)
        msg[i] ^= key[i];
    return msg;
}

void LoginSystem::RegisterPage()
{
	bool UserNamecheck = true;
	bool OccupationCheck = true;
	bool PassworCheck = true;
	bool NameCheck = true;
	bool EmailCheck = true;
	bool AddressCheck = true;
	bool ContactCheck = true;
	bool UserNameCheckEmpty = true;
	

	cout << endl;
	cout << "Welcome to Warehouse Management Registration" << endl;
	cout << "============================================" << endl;
	cout << endl;

	//cin.clear();
	//cin.ignore(1000, '\n');

	string uname;
	cout << "Username: ";
        getline(cin, uname);
	getline(cin, username);

	while (UserNameCheckEmpty)
	{

		if (!(username == ""))
		{
			UserNameCheckEmpty = false;
		}
		else
		{
			cout << "Please Key in Something" << endl;
			cout << "Username: ";
			getline(cin, username);
		}
	}

	if (LoginRec.size() > 0)
	{
		while (UserNamecheck)
		{
			UserNamecheck = false;
			for (int i = 0; i < LoginRec.size(); i++)
			{
				if ((LoginRec.at(i).Username == username))
				{
					UserNamecheck = true;
					cout << "Existing Username!" << endl;
					cout << "Username: ";
					getline(cin, username);
				}
			}
		}
	}


	string password = getpass("Password: ",true); 

	while (PassworCheck)
	{
		if (!(password == ""))
		{
			PassworCheck = false;
		}
		else
		{
			cout << "Please Key in Something" << endl;
			cout << "Password: ";
			getline(cin, password);
		}
	}
	

	cout << "Name: ";
	getline(cin, name);

	while (NameCheck)
	{
		if (!(name == ""))
		{
			NameCheck = false;
		}
		else
		{
			cout << "Please Key in Something" << endl;
			cout << "Name: ";
			getline(cin, name);
		}
	}

	cout << "Email: ";
	getline(cin, email);

	while (EmailCheck)
	{
		if (!(email == ""))
		{
			EmailCheck = false;
		}
		else
		{
			cout << "Please Key in Something" << endl;
			cout << "Email: ";
			getline(cin, email);
		}
	}

	cout << "Address: ";
	getline(cin, address);

	while (AddressCheck)
	{
		if (!(address == ""))
		{
			AddressCheck = false;
		}
		else
		{
			cout << "Please Key in Something" << endl;
			cout << "Address: ";
			getline(cin, address);
		}
	}

	cout << "Contact: ";

	while (true)
	{
		cin >> contact;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good())
			break;

		// If not valid, prompt user and clear previous cin
		cout << "Invalid contact input, please re-enter again!!!" << endl;
		cout << "Contact: ";
		cin.clear();
		cin.ignore(1000, '\n');
	}

	cin.clear();
	cin.ignore(1000, '\n');

	cout << "Occupation (Admin/Worker): ";
	getline(cin, accesslvl);

	while (OccupationCheck)
	{
		if ((accesslvl == "Admin") || (accesslvl == "Worker"))
		{
			OccupationCheck = false;

		}
		else
		{
			cout << "Please Enter Admin or Worker (Cap Sensitive)" << endl;
			cout << "Occupation: ";
			getline(cin, accesslvl);
		}
	}


	fstream TransferData;
	TransferData.open(INPUT_FILE_NAME, fstream::app);
	if (TransferData.is_open())
	{
		if (TransferData.good())
		{
			string pwd = Encrypt(password,"blah");
			TransferData << username << ":" << pwd << ":" << name << ":" << email << ":" << address << ":" << accesslvl << ":" << contact << endl;
		}
		else
		{
			cout << "Error occured while writing file! Please try again!" << endl << endl;
		}
	}
	else
	{
		cout << "Please try again!";
	}

	TransferData.close();

	cout << endl << "Registration Successful!\n" << endl;
	ReadDatabase();
}

void LoginSystem::GetSelection()
{
	while (true)
	{
		cin >> Selection;

		// check if input is a valid integer and valid choice; break from loop if valid.
		if (cin.peek() == '\n' && cin.good() && Selection >= 1 && Selection <= 3)
			break;

		// If not valid, prompt user and clear previous cin
		cout << "Please Do not Key in Alphabet" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
		LoginMenu();
		GetSelection();
		
	}
	switch (Selection)
	{
	case 1:
		cin.clear();
		cin.ignore(1000, '\n');
		LoginPage();
		break;

	case 2:
		cin.clear();
		cin.ignore(1000, '\n');
		cout << endl << "Thank you for using Warehouse Management System." << endl << endl;
		exit(0);
		break;
	default:
		cout << "You have key in an invalid option. Please try again. (1 to 3)" << endl;
		cout << "\n" << endl;
		LoginMenu();
		GetSelection();
		break;
	}
}

void LoginSystem::ReadDatabase()
{
	fstream RetrieveData;
	LoginRecord Record;

	RetrieveData.open(INPUT_FILE_NAME, fstream::in);
	if (!RetrieveData)
	{
		cout << "File not found! Please try again!" << endl;
	}
	else
	{

		string data;
		while (getline(RetrieveData, data))
		{
			istringstream a(data);

			getline(a, Record.Username, LINE_DATA_DELIMITER);
			getline(a, Record.Password, LINE_DATA_DELIMITER);
			getline(a, Record.Name, LINE_DATA_DELIMITER);
			getline(a, Record.Email, LINE_DATA_DELIMITER);
			getline(a, Record.Address, LINE_DATA_DELIMITER);
			getline(a, Record.AccessLVL, LINE_DATA_DELIMITER);
			a >> Record.Contact;
			a.ignore(1, ':');

			LoginRec.push_back(Record);
		}
	} RetrieveData.close();
}

