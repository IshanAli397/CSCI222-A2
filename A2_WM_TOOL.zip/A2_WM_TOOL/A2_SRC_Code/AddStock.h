#include "Stock.h"

class AddStock : public Stock
{
public:

	void addStock(int addstockitemID, int addstockincomingQty, string addstockitemDescrip, float addstockprice, string addstockcatergory, string addstocksubcatergory, string addstocktransactionDate);
};