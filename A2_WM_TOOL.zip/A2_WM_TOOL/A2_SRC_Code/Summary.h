#ifndef SUMMARY_H
#define SUMMARY_H

// ------------------------------------------------------------------------------------

#include <vector>
#include <string>
using namespace std;

// ------------------------------------------------------------------------------------

ostream& HeadingSummary(ostream &os)
{
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	os << "Date        " << "ID   " << "Description                   " << "Category      " << "Sub-Category    " << "Amount Per Unit  " << "Aggregated Qty   ";
	os << '\n';
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	return os.flush();

};

ostream& HeadingWeekSummary(ostream &os)
{
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	os << "Week     " << "Date      " << "ID   " << "Description                   " << "Category      " << "Sub-Category    " << "Amount Per Unit  " << "Aggregated Qty   ";
	os << '\n';
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	return os.flush();

};

ostream& HeadingMonthSummary(ostream &os)
{
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	os << "Month     " << "Date      " << "ID   " << "Description                   " << "Category      " << "Sub-Category    " << "Amount Per Unit  " << "Aggregated Qty   ";
	os << '\n';
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	return os.flush();

};

ostream& HeadingYearSummary(ostream &os)
{
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	os << "Year     " << "Date      " << "ID   " << "Description                   " << "Category      " << "Sub-Category    " << "Amount Per Unit  " << "Aggregated Qty   ";
	os << '\n';
	os << "---------------------------------------------------------------------------------------------------------";
	os << '\n';
	return os.flush();

};

ostream& manipIdSummary(ostream &os)
{

	os.width(5);
	os << left;
	return os.flush();

};

ostream& manipDescSummary(ostream &os)
{

	os.width(30);
	os << left;
	return os.flush();

};

ostream& manipCatSummary(ostream &os)
{

	os.width(14);
	os << left;
	return os.flush();

};

ostream& manipSubCatSummary(ostream &os)
{

	os.width(16);
	os << left;
	return os.flush();

};

ostream& manipPriceSummary(ostream &os)
{

	os.width(7);
	os << left;
	return os.flush();

};

ostream& manipQtySummary(ostream &os)
{

	os.width(11);
	os << left;
	return os.flush();

};

ostream& manipDateSummary(ostream &os)
{

	os.width(9);
	os << left;
	return os.flush();

};

#endif // SUMMARY_H
