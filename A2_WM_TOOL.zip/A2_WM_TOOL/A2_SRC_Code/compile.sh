g++ -std=c++11 Main.cpp AddStock.cpp SearchStock.cpp LoginSystem.cpp SystemMenu.cpp EditStock.cpp Summary.cpp RemoveStock.cpp -o /home/vmw_ubuntu/Desktop/Assn2/A2.exe
