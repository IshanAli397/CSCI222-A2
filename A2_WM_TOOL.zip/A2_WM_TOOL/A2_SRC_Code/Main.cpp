#include "LoginSystem.h"

using namespace std;

int main() 
{
	LoginSystem SystemActivate;
	SystemActivate.LoginMenu();
	SystemActivate.ReadDatabase();
	SystemActivate.GetSelection();
}
