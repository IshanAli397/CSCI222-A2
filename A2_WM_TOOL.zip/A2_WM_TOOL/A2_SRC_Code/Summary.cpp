#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "Stock.h"
#include "Summary.h"

using namespace std;

vector <WarehouseDB> summaryVector;


void Summary::summary()
{
	fstream filestream;
	string filename = "/home/vmw_ubuntu/Desktop/Assn2/A2_Data/SampleData.txt";
	WarehouseDB data;

	int itemId;
	string itemDesc;
	string itemCat;
	string itemSubCat;
	double price;
	int qty;
	string month1;
	string date;
	
	string fDate;
	string sDate;
	
	int day, year;
	char dash;

	int tempDay, tempYear;
	string tempMonth;
	
	int tempDay2, tempYear2;
	string tempMonth2;
	
	int monthWeight;
	int monthWeight2;
	int monthWeight3;

	string category;
	string subCategory;
	
	int idArr [300];
	string descArr [300];
	string catArr [300];
	string subCatArr [300];
	int priceArray [300];
	int qtyArr [300];
	int dayArr [300];
	string month1Arr [300];
	int yearArr [300];
	
	int nidArr [300];
	string ndescArr [300];
	string ncatArr [300];
	string nsubCatArr [300];
	int npriceArray [300];
	int nqtyArr [300];
	int ndayArr [300];
	string nmonth1Arr [300];
	int nyearArr [300];
	
	int distinct = 0;

	cin.clear();
	cin.ignore(1000, '\n');
	filestream.open(filename.c_str(), fstream::in);

	if (!filestream)
	{
		cout << endl << "Unable to open file, please check your filename or file existance!!!" << endl << endl;
	}
	
	else
	{
		string aLine = "";
		while (getline(filestream, aLine))
		{
			istringstream ss(aLine);
	
			ss >> data.itemId;
			ss.ignore(1, ':');
			getline(ss, data.itemDesc, ':');
			getline(ss, data.itemCat, ':');
			getline(ss, data.itemSubCat, ':');
			ss >> data.price;
			ss.ignore(1, ':');
			ss >> data.qty;
			ss.ignore(1, ':');
						
			ss >> data.day; 
			ss >> data.dash; 
			getline(ss, data.month1, '-');
			ss >> data.year;
		
			summaryVector.push_back(data);
		}
	}

	int subChoice;
	int counter = 0;
	int counter2 = 0;
	
	cout << endl;
	cout << "Warehouse Management Summary Report Menu " << endl;
	cout << "=========================================" << endl;
	cout << "1) Daily Summary Report" << endl;
	cout << "2) Weekly Summary Report(TBD) " << endl;
	cout << "3) Monthly Summary Report " << endl;
	cout << "4) Yearly Summary Report " << endl;
	cout << "=========================================" << endl;

	while (true)
	{
		cout << "Please enter your choice: ";
		cin >> subChoice;

		if (cin.peek() == '\n' && cin.good() && subChoice >= 1 && subChoice <= 4)
		break;

		cout << "Please key in a valid choice!!!" << endl;
		cin.clear();
		cin.ignore(1000, '\n');
	}
	
	if(subChoice == 1)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << endl << "Welcome to Daily Summary Report Generator" << endl;
		cout << "______________________" << endl << endl;
		
		cout << "Please enter start date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth);
		
		if (tempMonth == "Jan")
		{
			monthWeight = 1;
		}
		
		else if (tempMonth == "Feb")
		{
			monthWeight = 2;
		}
		
		else if (tempMonth == "Mar")
		{
			monthWeight = 3;
		}		

		else if (tempMonth == "Apr")
		{
			monthWeight = 4;
		}		

		else if (tempMonth == "May")
		{
			monthWeight = 5;
		}
		
		else if (tempMonth == "Jun")
		{
			monthWeight = 6;
		}		
		
		else if (tempMonth == "Jul")
		{
			monthWeight = 7;
		}		
		
		else if (tempMonth == "Aug")
		{
			monthWeight = 8;
		}		
		
		else if (tempMonth == "Sep")
		{
			monthWeight = 9;
		}

		else if (tempMonth == "Oct")
		{
			monthWeight = 10;
		}

		else if (tempMonth == "Nov")
		{
			monthWeight = 11;
		}

		else if (tempMonth == "Dec")
		{
			monthWeight = 12;
		}	

		cout << "Year (YY): ";
		cin >> tempYear;
		
		cout << endl;
		
		cout << "Please enter end date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay2;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth2);
		
		if (tempMonth2 == "Jan")
		{
			monthWeight2 = 1;
		}
		
		else if (tempMonth2 == "Feb")
		{
			monthWeight2 = 2;
		}
		
		else if (tempMonth2 == "Mar")
		{
			monthWeight2 = 3;
		}		

		else if (tempMonth2 == "Apr")
		{
			monthWeight2 = 4;
		}		

		else if (tempMonth2 == "May")
		{
			monthWeight2 = 5;
		}
		
		else if (tempMonth2 == "Jun")
		{
			monthWeight2 = 6;
		}		
		
		else if (tempMonth2 == "Jul")
		{
			monthWeight2 = 7;
		}		
		
		else if (tempMonth2 == "Aug")
		{
			monthWeight2 = 8;
		}		
		
		else if (tempMonth2 == "Sep")
		{
			monthWeight2 = 9;
		}

		else if (tempMonth2 == "Oct")
		{
			monthWeight2 = 10;
		}

		else if (tempMonth2 == "Nov")
		{
			monthWeight2 = 11;
		}

		else if (tempMonth2 == "Dec")
		{
			monthWeight2 = 12;
		}	
			
		cout << "Year: ";
		cin >> tempYear2;
		
		cout << endl;

		cout << HeadingSummary;
		
		int xy = 0;	

		for (int i = 0; i < summaryVector.size(); i++)
		{										
			if (summaryVector.at(i).month1 == "Jan")
			{
				monthWeight3 = 1;
			}
			
			else if (summaryVector.at(i).month1 == "Feb")
			{
				monthWeight3 = 2;
			}
			
			else if (summaryVector.at(i).month1 == "Mar")
			{
				monthWeight3 = 3;
			}		

			else if (summaryVector.at(i).month1 == "Apr")
			{
				monthWeight3 = 4;
			}		

			else if (summaryVector.at(i).month1 == "May")
			{
				monthWeight3 = 5;
			}
			
			else if (summaryVector.at(i).month1 == "Jun")
			{
				monthWeight3 = 6;
			}		
			
			else if (summaryVector.at(i).month1 == "Jul")
			{
				monthWeight3 = 7;
			}		
			
			else if (summaryVector.at(i).month1 == "Aug")
			{
				monthWeight3 = 8;
			}		
			
			else if (summaryVector.at(i).month1 == "Sep")
			{
				monthWeight3 = 9;
			}

			else if (summaryVector.at(i).month1 == "Oct")
			{
				monthWeight3 = 10;
			}

			else if (summaryVector.at(i).month1 == "Nov")
			{
				monthWeight3 = 11;
			} 

			else if (summaryVector.at(i).month1 == "Dec")
			{
				monthWeight3 = 12;
			}	
			
			int holdInt = 0;
			
			int dateWeight = 0;
			int dateStartWeight = 0;
			int dateEndWeight = 0;


			dateWeight = (summaryVector.at(i).year * 100000) + (monthWeight3 * 1000) + summaryVector.at(i).day;
			dateStartWeight = (tempYear * 100000) + (monthWeight * 1000) + tempDay;
			dateEndWeight =  (tempYear2 * 100000) + (monthWeight2 * 1000) + tempDay2;

								
			if (dateWeight >= dateStartWeight && dateWeight <= dateEndWeight)
			{										
					if (idArr [xy] == summaryVector.at(i).itemId && descArr [xy] == summaryVector.at(i).itemDesc)
					{
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
					}
						
					else
					{			
			
						idArr [xy] = summaryVector.at(i).itemId;
						descArr [xy] = summaryVector.at(i).itemDesc;
						catArr [xy] = summaryVector.at(i).itemCat;
						subCatArr [xy] = summaryVector.at(i).itemSubCat;
						priceArray [xy] = summaryVector.at(i).price;
														
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
									
						dayArr [xy] = summaryVector.at(i).day;
						month1Arr [xy] = summaryVector.at(i).month1;
						yearArr [xy] = summaryVector.at(i).year;
									
						distinct++;
						xy++;
					}						
			}
		}
						
		for (int jj = 0; jj < distinct; jj++)//loop through array
		{			
			for (int qq = 0; qq < jj; qq++)//loop through temp array
			{
				if (idArr [jj] == idArr [qq] && idArr[jj] != 0 && (dayArr[jj] == dayArr[qq] && month1Arr[jj] == month1Arr[qq] && yearArr[jj] == yearArr[qq]) )//if same id is found
				{
					qtyArr[jj] =qtyArr[jj] + qtyArr[qq];
					idArr[qq] = 0;
					qtyArr [qq] = 0;
				}
			}
		}	
                for (int jj = 0; jj < distinct; jj++) 
		{
			if (idArr[jj] != 0) {		
				cout << dayArr[jj] << "-" << month1Arr[jj] << "-" << yearArr[jj];
				cout << "   " << manipIdSummary << idArr[jj];
				cout << manipDescSummary << descArr[jj];
				cout << manipCatSummary << catArr[jj];
				cout << manipSubCatSummary << subCatArr[jj] ;
				cout << manipPriceSummary << priceArray[jj];
				cout << "          " << manipQtySummary << qtyArr[jj];
				cout << endl;	
			}
		}	
	}	//End of daily

	if(subChoice == 2)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << endl << "Welcome to Monthly Summary Report Generator" << endl;
		cout << "______________________" << endl << endl;
		
		cout << "Please enter start date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth);
		
		if (tempMonth == "Jan")
		{
			monthWeight = 1;
		}
		
		else if (tempMonth == "Feb")
		{
			monthWeight = 2;
		}
		
		else if (tempMonth == "Mar")
		{
			monthWeight = 3;
		}		

		else if (tempMonth == "Apr")
		{
			monthWeight = 4;
		}		

		else if (tempMonth == "May")
		{
			monthWeight = 5;
		}
		
		else if (tempMonth == "Jun")
		{
			monthWeight = 6;
		}		
		
		else if (tempMonth == "Jul")
		{
			monthWeight = 7;
		}		
		
		else if (tempMonth == "Aug")
		{
			monthWeight = 8;
		}		
		
		else if (tempMonth == "Sep")
		{
			monthWeight = 9;
		}

		else if (tempMonth == "Oct")
		{
			monthWeight = 10;
		}

		else if (tempMonth == "Nov")
		{
			monthWeight = 11;
		}

		else if (tempMonth == "Dec")
		{
			monthWeight = 12;
		}	

		cout << "Year (YY): ";
		cin >> tempYear;
		
		cout << endl;
		
		cout << "Please enter end date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay2;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth2);
		
		if (tempMonth2 == "Jan")
		{
			monthWeight2 = 1;
		}
		
		else if (tempMonth2 == "Feb")
		{
			monthWeight2 = 2;
		}
		
		else if (tempMonth2 == "Mar")
		{
			monthWeight2 = 3;
		}		

		else if (tempMonth2 == "Apr")
		{
			monthWeight2 = 4;
		}		

		else if (tempMonth2 == "May")
		{
			monthWeight2 = 5;
		}
		
		else if (tempMonth2 == "Jun")
		{
			monthWeight2 = 6;
		}		
		
		else if (tempMonth2 == "Jul")
		{
			monthWeight2 = 7;
		}		
		
		else if (tempMonth2 == "Aug")
		{
			monthWeight2 = 8;
		}		
		
		else if (tempMonth2 == "Sep")
		{
			monthWeight2 = 9;
		}

		else if (tempMonth2 == "Oct")
		{
			monthWeight2 = 10;
		}

		else if (tempMonth2 == "Nov")
		{
			monthWeight2 = 11;
		}

		else if (tempMonth2 == "Dec")
		{
			monthWeight2 = 12;
		}	
			
		cout << "Year: ";
		cin >> tempYear2;
		
		cout << endl;

		cout << HeadingWeekSummary;
		
		int xy = 0;	
		
		for (int i = 0; i < summaryVector.size(); i++)
		{										
			if (summaryVector.at(i).month1 == "Jan")
			{
				monthWeight3 = 1;
			}
			
			else if (summaryVector.at(i).month1 == "Feb")
			{
				monthWeight3 = 2;
			}
			
			else if (summaryVector.at(i).month1 == "Mar")
			{
				monthWeight3 = 3;
			}		

			else if (summaryVector.at(i).month1 == "Apr")
			{
				monthWeight3 = 4;
			}		

			else if (summaryVector.at(i).month1 == "May")
			{
				monthWeight3 = 5;
			}
			
			else if (summaryVector.at(i).month1 == "Jun")
			{
				monthWeight3 = 6;
			}		
			
			else if (summaryVector.at(i).month1 == "Jul")
			{
				monthWeight3 = 7;
			}		
			
			else if (summaryVector.at(i).month1 == "Aug")
			{
				monthWeight3 = 8;
			}		
			
			else if (summaryVector.at(i).month1 == "Sep")
			{
				monthWeight3 = 9;
			}

			else if (summaryVector.at(i).month1 == "Oct")
			{
				monthWeight3 = 10;
			}

			else if (summaryVector.at(i).month1 == "Nov")
			{
				monthWeight3 = 11;
			} 

			else if (summaryVector.at(i).month1 == "Dec")
			{
				monthWeight3 = 12;
			}	
			
			int holdInt = 0;
			
			int dateWeight = 0;
			int dateStartWeight = 0;
			int dateEndWeight = 0;


			dateWeight = (summaryVector.at(i).year * 100000) + (monthWeight3 * 1000) + summaryVector.at(i).day;
			dateStartWeight = (tempYear * 100000) + (monthWeight * 1000) + tempDay;
			dateEndWeight =  (tempYear2 * 100000) + (monthWeight2 * 1000) + tempDay2;

								
			if (dateWeight >= dateStartWeight && dateWeight <= dateEndWeight)
			{										
					if (idArr [xy] == summaryVector.at(i).itemId && descArr [xy] == summaryVector.at(i).itemDesc)
					{
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
					}
						
					else
					{			
			
						idArr [xy] = summaryVector.at(i).itemId;
						descArr [xy] = summaryVector.at(i).itemDesc;
						catArr [xy] = summaryVector.at(i).itemCat;
						subCatArr [xy] = summaryVector.at(i).itemSubCat;
						priceArray [xy] = summaryVector.at(i).price;
														
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
									
						dayArr [xy] = summaryVector.at(i).day;
						month1Arr [xy] = summaryVector.at(i).month1;
						yearArr [xy] = summaryVector.at(i).year;
									
						distinct++;
						xy++;
					}						
			}
		}
						
		for (int jj = 0; jj < distinct; jj++)//loop through array
		{			
			for (int qq = 0; qq < jj; qq++)//loop through temp array
			{
				if (idArr [jj] == idArr [qq] && idArr[jj] != 0 && (dayArr[jj] == dayArr[qq] && month1Arr[jj] == month1Arr[qq] && yearArr[jj] == yearArr[qq]) )//if same id is found
				{
					qtyArr[jj] =qtyArr[jj] + qtyArr[qq];
					idArr[qq] = 0;
					qtyArr [qq] = 0;
				}
			}
		}	
                for (int jj = 0; jj < distinct; jj++) 
		{
			if (idArr[jj] != 0) {		
				cout << dayArr[jj] << "-" << month1Arr[jj] << "-" << yearArr[jj];
				cout << "  " << manipIdSummary << idArr[jj];
				cout << manipDescSummary << descArr[jj];
				cout << manipCatSummary << catArr[jj];
				cout << manipSubCatSummary << subCatArr[jj] ;
				cout << manipPriceSummary << priceArray[jj];
				cout << "          " << manipQtySummary << qtyArr[jj];
				cout << endl;	
			}
		}	
	}//End weekly

if(subChoice == 3)
	{
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << endl << "Welcome to Monthly Summary Report Generator" << endl;
		cout << "______________________" << endl << endl;
		
		cout << "Please enter start date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth);
		
		if (tempMonth == "Jan")
		{
			monthWeight = 1;
		}
		
		else if (tempMonth == "Feb")
		{
			monthWeight = 2;
		}
		
		else if (tempMonth == "Mar")
		{
			monthWeight = 3;
		}		

		else if (tempMonth == "Apr")
		{
			monthWeight = 4;
		}		

		else if (tempMonth == "May")
		{
			monthWeight = 5;
		}
		
		else if (tempMonth == "Jun")
		{
			monthWeight = 6;
		}		
		
		else if (tempMonth == "Jul")
		{
			monthWeight = 7;
		}		
		
		else if (tempMonth == "Aug")
		{
			monthWeight = 8;
		}		
		
		else if (tempMonth == "Sep")
		{
			monthWeight = 9;
		}

		else if (tempMonth == "Oct")
		{
			monthWeight = 10;
		}

		else if (tempMonth == "Nov")
		{
			monthWeight = 11;
		}

		else if (tempMonth == "Dec")
		{
			monthWeight = 12;
		}	

		cout << "Year (YY): ";
		cin >> tempYear;
		
		cout << endl;
		
		cout << "Please enter end date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay2;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth2);
		
		if (tempMonth2 == "Jan")
		{
			monthWeight2 = 1;
		}
		
		else if (tempMonth2 == "Feb")
		{
			monthWeight2 = 2;
		}
		
		else if (tempMonth2 == "Mar")
		{
			monthWeight2 = 3;
		}		

		else if (tempMonth2 == "Apr")
		{
			monthWeight2 = 4;
		}		

		else if (tempMonth2 == "May")
		{
			monthWeight2 = 5;
		}
		
		else if (tempMonth2 == "Jun")
		{
			monthWeight2 = 6;
		}		
		
		else if (tempMonth2 == "Jul")
		{
			monthWeight2 = 7;
		}		
		
		else if (tempMonth2 == "Aug")
		{
			monthWeight2 = 8;
		}		
		
		else if (tempMonth2 == "Sep")
		{
			monthWeight2 = 9;
		}

		else if (tempMonth2 == "Oct")
		{
			monthWeight2 = 10;
		}

		else if (tempMonth2 == "Nov")
		{
			monthWeight2 = 11;
		}

		else if (tempMonth2 == "Dec")
		{
			monthWeight2 = 12;
		}	
			
		cout << "Year: ";
		cin >> tempYear2;
		
		cout << endl;

		cout << HeadingMonthSummary;
		
		int xy = 0;	
		
		for (int i = 0; i < summaryVector.size(); i++)
		{										
			if (summaryVector.at(i).month1 == "Jan")
			{
				monthWeight3 = 1;
			}
			
			else if (summaryVector.at(i).month1 == "Feb")
			{
				monthWeight3 = 2;
			}
			
			else if (summaryVector.at(i).month1 == "Mar")
			{
				monthWeight3 = 3;
			}		

			else if (summaryVector.at(i).month1 == "Apr")
			{
				monthWeight3 = 4;
			}		

			else if (summaryVector.at(i).month1 == "May")
			{
				monthWeight3 = 5;
			}
			
			else if (summaryVector.at(i).month1 == "Jun")
			{
				monthWeight3 = 6;
			}		
			
			else if (summaryVector.at(i).month1 == "Jul")
			{
				monthWeight3 = 7;
			}		
			
			else if (summaryVector.at(i).month1 == "Aug")
			{
				monthWeight3 = 8;
			}		
			
			else if (summaryVector.at(i).month1 == "Sep")
			{
				monthWeight3 = 9;
			}

			else if (summaryVector.at(i).month1 == "Oct")
			{
				monthWeight3 = 10;
			}

			else if (summaryVector.at(i).month1 == "Nov")
			{
				monthWeight3 = 11;
			} 

			else if (summaryVector.at(i).month1 == "Dec")
			{
				monthWeight3 = 12;
			}	
			
			int holdInt = 0;
			
			int dateWeight = 0;
			int dateStartWeight = 0;
			int dateEndWeight = 0;


			dateWeight = (summaryVector.at(i).year * 100000) + (monthWeight3 * 1000) + summaryVector.at(i).day;
			dateStartWeight = (tempYear * 100000) + (monthWeight * 1000) + tempDay;
			dateEndWeight =  (tempYear2 * 100000) + (monthWeight2 * 1000) + tempDay2;

								
			if (dateWeight >= dateStartWeight && dateWeight <= dateEndWeight)
			{										
					if (idArr [xy] == summaryVector.at(i).itemId && descArr [xy] == summaryVector.at(i).itemDesc)
					{
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
					}
						
					else
					{			
			
						idArr [xy] = summaryVector.at(i).itemId;
						descArr [xy] = summaryVector.at(i).itemDesc;
						catArr [xy] = summaryVector.at(i).itemCat;
						subCatArr [xy] = summaryVector.at(i).itemSubCat;
						priceArray [xy] = summaryVector.at(i).price;
														
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
									
						dayArr [xy] = summaryVector.at(i).day;
						month1Arr [xy] = summaryVector.at(i).month1;
						yearArr [xy] = summaryVector.at(i).year;
									
						distinct++;
						xy++;
					}						
			}
		}
			
						
		for (int jj = 0; jj < distinct; jj++)//loop through array
		{			
			for (int qq = 0; qq < jj; qq++)//loop through temp array
			{
				if (idArr [jj] == idArr [qq] && idArr[jj] != 0 && (dayArr[jj] == dayArr[qq] && month1Arr[jj] == month1Arr[qq] && yearArr[jj] == yearArr[qq]) )//if same id is found
				{
					qtyArr[jj] =qtyArr[jj] + qtyArr[qq];
					idArr[qq] = 0;
					qtyArr [qq] = 0;
				}
			}
		}	
                for (int jj = 0; jj < distinct; jj++) 
		{
			int subMonth = 0;
			int gg = 1;
			int subYear2 = 0;
			int monthWeight5 = 0;
			
			if (idArr[jj] != 0) 
			{
				subMonth = monthWeight;
				subYear2 = tempYear;
				
				if (subMonth > 12)
				{
					subMonth++;
					tempYear++;
				}
				
				else
				{
					while (subMonth <= monthWeight2 && subYear2 <= tempYear2)
					{						
						if (month1Arr[jj] == "Jan")
						{
							monthWeight5 = 1;
						}
						
						else if (month1Arr[jj] == "Feb")
						{
							monthWeight5 = 2;
						}
						
						else if (month1Arr[jj] == "Mar")
						{
							monthWeight5 = 3;
						}		

						else if (month1Arr[jj] == "Apr")
						{
							monthWeight5 = 4;
						}		

						else if (month1Arr[jj] == "May")
						{
							monthWeight5 = 5;
						}
						
						else if (month1Arr[jj] == "Jun")
						{
							monthWeight5 = 6;
						}		
						
						else if (month1Arr[jj] == "Jul")
						{
							monthWeight5 = 7;
						}		
						
						else if (month1Arr[jj] == "Aug")
						{
							monthWeight5 = 8;
						}		
						
						else if (month1Arr[jj] == "Sep")
						{
							monthWeight5 = 9;
						}

						else if (month1Arr[jj] == "Oct")
						{
							monthWeight5 = 10;
						}

						else if (month1Arr[jj] == "Nov")
						{
							monthWeight5 = 11;
						}

						else if (month1Arr[jj] == "Dec")
						{
							monthWeight5 = 12;
						}	
																		
						if (monthWeight5 == subMonth)
						{
							cout << gg <<  "       ";
							cout << dayArr[jj] << "-" << month1Arr[jj] << "-" << yearArr[jj];
							cout << "   " << manipIdSummary << idArr[jj];
							cout << manipDescSummary << descArr[jj];
							cout << manipCatSummary << catArr[jj];
							cout << manipSubCatSummary << subCatArr[jj] ;
							cout << manipPriceSummary << priceArray[jj];
							cout << "          " << manipQtySummary << qtyArr[jj];
							cout << endl;	
						}
						
						subMonth++;
						gg++;
					}
				}
			}
		}		
	}//End monthly	

if(subChoice == 4)
	{
				cin.clear();
		cin.ignore(1000, '\n');
		
		cout << endl << "Welcome to Yearly Summary Report Generator" << endl;
		cout << "______________________" << endl << endl;
		
		cout << "Please enter start date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth);
		
		if (tempMonth == "Jan")
		{
			monthWeight = 1;
		}
		
		else if (tempMonth == "Feb")
		{
			monthWeight = 2;
		}
		
		else if (tempMonth == "Mar")
		{
			monthWeight = 3;
		}		

		else if (tempMonth == "Apr")
		{
			monthWeight = 4;
		}		

		else if (tempMonth == "May")
		{
			monthWeight = 5;
		}
		
		else if (tempMonth == "Jun")
		{
			monthWeight = 6;
		}		
		
		else if (tempMonth == "Jul")
		{
			monthWeight = 7;
		}		
		
		else if (tempMonth == "Aug")
		{
			monthWeight = 8;
		}		
		
		else if (tempMonth == "Sep")
		{
			monthWeight = 9;
		}

		else if (tempMonth == "Oct")
		{
			monthWeight = 10;
		}

		else if (tempMonth == "Nov")
		{
			monthWeight = 11;
		}

		else if (tempMonth == "Dec")
		{
			monthWeight = 12;
		}	

		cout << "Year (YY): ";
		cin >> tempYear;
		
		cout << endl;
		
		cout << "Please enter end date";
		cout << endl;
		
		cout << "Day (DD): ";
		cin >> tempDay2;
		
		cin.clear();
		cin.ignore(1000, '\n');
		
		cout << "Month (MMM): ";
		getline(cin, tempMonth2);
		
		if (tempMonth2 == "Jan")
		{
			monthWeight2 = 1;
		}
		
		else if (tempMonth2 == "Feb")
		{
			monthWeight2 = 2;
		}
		
		else if (tempMonth2 == "Mar")
		{
			monthWeight2 = 3;
		}		

		else if (tempMonth2 == "Apr")
		{
			monthWeight2 = 4;
		}		

		else if (tempMonth2 == "May")
		{
			monthWeight2 = 5;
		}
		
		else if (tempMonth2 == "Jun")
		{
			monthWeight2 = 6;
		}		
		
		else if (tempMonth2 == "Jul")
		{
			monthWeight2 = 7;
		}		
		
		else if (tempMonth2 == "Aug")
		{
			monthWeight2 = 8;
		}		
		
		else if (tempMonth2 == "Sep")
		{
			monthWeight2 = 9;
		}

		else if (tempMonth2 == "Oct")
		{
			monthWeight2 = 10;
		}

		else if (tempMonth2 == "Nov")
		{
			monthWeight2 = 11;
		}

		else if (tempMonth2 == "Dec")
		{
			monthWeight2 = 12;
		}	
			
		cout << "Year: ";
		cin >> tempYear2;
		
		cout << endl;

		cout << HeadingYearSummary;
		
		int xy = 0;	
		
		for (int i = 0; i < summaryVector.size(); i++)
		{										
			if (summaryVector.at(i).month1 == "Jan")
			{
				monthWeight3 = 1;
			}
			
			else if (summaryVector.at(i).month1 == "Feb")
			{
				monthWeight3 = 2;
			}
			
			else if (summaryVector.at(i).month1 == "Mar")
			{
				monthWeight3 = 3;
			}		

			else if (summaryVector.at(i).month1 == "Apr")
			{
				monthWeight3 = 4;
			}		

			else if (summaryVector.at(i).month1 == "May")
			{
				monthWeight3 = 5;
			}
			
			else if (summaryVector.at(i).month1 == "Jun")
			{
				monthWeight3 = 6;
			}		
			
			else if (summaryVector.at(i).month1 == "Jul")
			{
				monthWeight3 = 7;
			}		
			
			else if (summaryVector.at(i).month1 == "Aug")
			{
				monthWeight3 = 8;
			}		
			
			else if (summaryVector.at(i).month1 == "Sep")
			{
				monthWeight3 = 9;
			}

			else if (summaryVector.at(i).month1 == "Oct")
			{
				monthWeight3 = 10;
			}

			else if (summaryVector.at(i).month1 == "Nov")
			{
				monthWeight3 = 11;
			} 

			else if (summaryVector.at(i).month1 == "Dec")
			{
				monthWeight3 = 12;
			}	
			
			int holdInt = 0;
			
			int dateWeight = 0;
			int dateStartWeight = 0;
			int dateEndWeight = 0;


			dateWeight = (summaryVector.at(i).year * 100000) + (monthWeight3 * 1000) + summaryVector.at(i).day;
			dateStartWeight = (tempYear * 100000) + (monthWeight * 1000) + tempDay;
			dateEndWeight =  (tempYear2 * 100000) + (monthWeight2 * 1000) + tempDay2;

								
			if (dateWeight >= dateStartWeight && dateWeight <= dateEndWeight)
			{										
					if (idArr [xy] == summaryVector.at(i).itemId && descArr [xy] == summaryVector.at(i).itemDesc)
					{
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
					}
						
					else
					{			
			
						idArr [xy] = summaryVector.at(i).itemId;
						descArr [xy] = summaryVector.at(i).itemDesc;
						catArr [xy] = summaryVector.at(i).itemCat;
						subCatArr [xy] = summaryVector.at(i).itemSubCat;
						priceArray [xy] = summaryVector.at(i).price;
														
						holdInt = holdInt + summaryVector.at(i).qty;				
						qtyArr [xy] = holdInt;
									
						dayArr [xy] = summaryVector.at(i).day;
						month1Arr [xy] = summaryVector.at(i).month1;
						yearArr [xy] = summaryVector.at(i).year;
									
						distinct++;
						xy++;
					}						
			}
		}
			
						
		for (int jj = 0; jj < distinct; jj++)//loop through array
		{			
			for (int qq = 0; qq < jj; qq++)//loop through temp array
			{
				if (idArr [jj] == idArr [qq] && idArr[jj] != 0 && (dayArr[jj] == dayArr[qq] && month1Arr[jj] == month1Arr[qq] && yearArr[jj] == yearArr[qq]) )//if same id is found
				{
					qtyArr[jj] =qtyArr[jj] + qtyArr[qq];
					idArr[qq] = 0;
					qtyArr [qq] = 0;
				}
			}
		}	
                for (int jj = 0; jj < distinct; jj++) 
		{
			int subYear = 0;
			int uu = 1;
			if (idArr[jj] != 0) 
			{
				subYear = tempYear;
				
				while (subYear <= tempYear2)
				{
					if (yearArr[jj] == subYear)
					{
					cout << manipIdSummary << uu << "    ";
					cout << dayArr[jj] << "-" << month1Arr[jj] << "-" << yearArr[jj];
					cout << " " << manipIdSummary << idArr[jj];
					cout << manipDescSummary << descArr[jj];
					cout << manipCatSummary << catArr[jj];
					cout << manipSubCatSummary << subCatArr[jj] ;
					cout << manipPriceSummary << priceArray[jj];
					cout << "          " << manipQtySummary << qtyArr[jj];
					cout << endl;	
					}
					
					subYear++;
					uu++;
				}
			}
		}	
	}//End yearly		
	summaryVector.clear();
}


